package com.example.contactinfoapp

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.contactinfoapp.databinding.ActivityEditContactBinding

class EditContactActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEditContactBinding
    private val viewModel: ContactViewModel by viewModels(ownerProducer = { this@EditContactActivity })

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityEditContactBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.nameEditText.setText(viewModel.name)
        binding.phoneEditText.setText(viewModel.phone)
        binding.emailEditText.setText(viewModel.email)

        binding.saveButton.setOnClickListener {
            viewModel.name = binding.nameEditText.text.toString()
            viewModel.phone = binding.phoneEditText.text.toString()
            viewModel.email = binding.emailEditText.text.toString()
            finish()
        }
    }
}
