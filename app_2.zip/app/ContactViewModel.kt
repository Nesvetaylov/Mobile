package com.example.contactinfoapp

import androidx.lifecycle.ViewModel

class ContactViewModel : ViewModel() {
    var name: String = ""
    var phone: String = ""
    var email: String = ""
}
