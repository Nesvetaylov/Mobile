package com.example.contactinfoapp

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.contactinfoapp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: ContactViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        updateContactInfo()

        binding.editButton.setOnClickListener {
            val intent = Intent(this, EditContactActivity::class.java)
            startActivity(intent)
        }
    }

    override fun onResume() {
        super.onResume()
        updateContactInfo()
    }

    private fun updateContactInfo() {
        val info = """
            Имя: ${viewModel.name}
            Телефон: ${viewModel.phone}
            Email: ${viewModel.email}
        """.trimIndent()

        binding.contactInfoTextView.text = if (viewModel.name.isNotEmpty()) info
        else getString(R.string.default_contact)
    }
}
