package com.example.calcapp

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var editTextNumber: EditText
    private lateinit var textOperation: TextView
    private lateinit var textResult: TextView

    private var currentOperation: String? = null
    private var result: Double? = null
    private var isNewOperation = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editTextNumber = findViewById(R.id.editTextNumber)
        textOperation = findViewById(R.id.textOperation)
        textResult = findViewById(R.id.textResult)

        val numberButtons = listOf(
            R.id.button0, R.id.button1, R.id.button2, R.id.button3, R.id.button4,
            R.id.button5, R.id.button6, R.id.button7, R.id.button8, R.id.button9
        )

        numberButtons.forEach { id ->
            findViewById<Button>(id).setOnClickListener {
                if (isNewOperation) {
                    editTextNumber.setText("")
                    isNewOperation = false
                }
                editTextNumber.append((it as Button).text)
            }
        }

        findViewById<Button>(R.id.buttonDot).setOnClickListener {
            if (!editTextNumber.text.contains(".")) {
                if (isNewOperation) {
                    editTextNumber.setText("")
                    isNewOperation = false
                }
                editTextNumber.append(".")
            }
        }

        findViewById<Button>(R.id.buttonAC).setOnClickListener {
            editTextNumber.text.clear()
            textOperation.text = ""
            textResult.text = ""
            result = null
            currentOperation = null
            isNewOperation = true
        }

        mapOf(
            R.id.buttonPlus to "+",
            R.id.buttonMinus to "-",
            R.id.buttonMultiply to "*",
            R.id.buttonDivide to "/"
        ).forEach { (id, op) ->
            findViewById<Button>(id).setOnClickListener {
                onOperatorPressed(op)
            }
        }

        findViewById<Button>(R.id.buttonEquals).setOnClickListener {
            onEqualPressed()
        }
    }

    private fun onOperatorPressed(op: String) {
        val input = editTextNumber.text.toString().toDoubleOrNull()
        if (input == null) {
            Toast.makeText(this, "Введите число", Toast.LENGTH_SHORT).show()
            return
        }

        if (result == null) {
            result = input
        } else if (currentOperation != null) {
            result = calculate(result!!, input, currentOperation!!)
        }

        currentOperation = op
        textOperation.text = op
        textResult.text = result.toString()
        editTextNumber.text.clear()
        isNewOperation = true
    }

    private fun onEqualPressed() {
        val input = editTextNumber.text.toString().toDoubleOrNull()
        if (input == null || currentOperation == null) {
            return
        }

        result = calculate(result ?: 0.0, input, currentOperation!!)
        textResult.text = result.toString()
        textOperation.text = ""
        editTextNumber.text.clear()
        currentOperation = null
        isNewOperation = true
    }

    private fun calculate(a: Double, b: Double, op: String): Double {
        return when (op) {
            "+" -> a + b
            "-" -> a - b
            "*" -> a * b
            "/" -> {
                if (b == 0.0) {
                    Toast.makeText(this, "Ошибка: деление на ноль", Toast.LENGTH_SHORT).show()
                    a
                } else {
                    a / b
                }
            }
            else -> b
        }
    }
}
